package com.mylearningacademy.howie.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;

import com.mylearningacademy.howie.account.dto.DirectorateDto;

public interface DirectorateService {
	HttpStatus registerDir(DirectorateDto dirDto);

}
