package com.mylearningacademy.howie.account.entity;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "request")
public class Request {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="user_id_generator")
	@SequenceGenerator(name = "user_id_generator", sequenceName="req_id_seq", initialValue=1, allocationSize=1)
	Integer req_id;
	
	String directorate;
	String division;
	String nasaprogram;
	String startdate;
	String enddate;
	String justification;
	String sponsoringorg;
	String fundingsource;
	String fundingmanager;
	
	Date createdby;
	
	
	public Date getCreatedby() {
		return createdby;
	}
	public void setCreatedby(Date createdby) {
		this.createdby = createdby;
	}
	public Integer getRequest_id() {
		return req_id;
	}
	public void setRequest_id(Integer request_id) {
		this.req_id = request_id;
	}
	
	public String getDirectorate() {
		return directorate;
	}
	public void setDirectorate(String directorate) {
		this.directorate = directorate;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getNasaprogram() {
		return nasaprogram;
	}
	public void setNasaprogram(String nasaprogram) {
		this.nasaprogram = nasaprogram;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	public String getJustification() {
		return justification;
	}
	public void setJustification(String justification) {
		this.justification = justification;
	}
	public String getSponsoringorg() {
		return sponsoringorg;
	}
	public void setSponsoringorg(String sponsoringorg) {
		this.sponsoringorg = sponsoringorg;
	}
	public String getFundingsource() {
		return fundingsource;
	}
	public void setFundingsource(String fundingsource) {
		this.fundingsource = fundingsource;
	}
	public String getFundingmanager() {
		return fundingmanager;
	}
	public void setFundingmanager(String fundingmanager) {
		this.fundingmanager = fundingmanager;
	}
	
	
}