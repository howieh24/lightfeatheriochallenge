package com.mylearningacademy.howie.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.mylearningacademy.howie.account.dto.ProgramDto;
import com.mylearningacademy.howie.account.entity.Program;
import com.mylearningacademy.howie.account.repository.ProgramRepository;

@Service
public class ProgramServiceImpl implements ProgramService{
	@Autowired
	ProgramRepository progRepo;
	
	@Override
	public HttpStatus registerProg(ProgramDto progDto) {
		Program prog = new Program();
		prog.setProjectId(progDto.getProgramId());
		prog.setProjectName(progDto.getProjectName());
		
		this.progRepo.save(prog);
		
		return HttpStatus.OK;
	}

}
