package com.mylearningacademy.howie.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.mylearningacademy.howie.account.dto.DivisionDto;
import com.mylearningacademy.howie.account.entity.Division;
import com.mylearningacademy.howie.account.repository.DivisionRepository;

@Service
public class DivisionServiceImpl implements DivisionService{
	@Autowired
	DivisionRepository divRepo;
	
	@Override
	public HttpStatus registerDiv(DivisionDto divDto) {
		Division div = new Division();
		div.setDivisionId(divDto.getDivisionId());
		div.setDivision(divDto.getDivision());
		
		return HttpStatus.OK;
	}

}
