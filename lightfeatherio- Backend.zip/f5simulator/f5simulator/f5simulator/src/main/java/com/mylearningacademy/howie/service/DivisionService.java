package com.mylearningacademy.howie.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import com.mylearningacademy.howie.account.dto.DivisionDto;

public interface DivisionService {
	HttpStatus registerDiv(DivisionDto custDto);

}
