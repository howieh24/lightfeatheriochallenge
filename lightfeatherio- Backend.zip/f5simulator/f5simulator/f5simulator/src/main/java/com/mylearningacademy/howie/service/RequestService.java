package com.mylearningacademy.howie.service;
import org.springframework.http.HttpStatus;

import com.mylearningacademy.howie.account.dto.RequestDto;

public interface RequestService {
	HttpStatus request(RequestDto reqDto);
	//String updateRequest(RequestDto reqDto);

}
