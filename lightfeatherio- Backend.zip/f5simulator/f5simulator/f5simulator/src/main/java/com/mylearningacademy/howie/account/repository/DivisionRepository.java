package com.mylearningacademy.howie.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mylearningacademy.howie.account.entity.Directorate;
import com.mylearningacademy.howie.account.entity.Division;

public interface DivisionRepository extends JpaRepository<Division, Integer> {

}
