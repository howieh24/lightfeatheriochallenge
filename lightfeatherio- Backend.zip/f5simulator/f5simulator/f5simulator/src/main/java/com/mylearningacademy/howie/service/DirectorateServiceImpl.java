package com.mylearningacademy.howie.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.mylearningacademy.howie.account.dto.DirectorateDto;
import com.mylearningacademy.howie.account.entity.Directorate;
import com.mylearningacademy.howie.account.repository.DirectorateRepository;

@Service
public class DirectorateServiceImpl implements DirectorateService{
	@Autowired
	DirectorateRepository dirRepo;
	
	@Override
	public HttpStatus registerDir(DirectorateDto dirDto) {
		Directorate dir = new Directorate();
		dir.setDirectorateID(dirDto.getDirectorateID());
		dir.setDirectorate(dirDto.getDirectorateName());
		
		this.dirRepo.save(dir);
		
		return HttpStatus.OK;
	}

}
