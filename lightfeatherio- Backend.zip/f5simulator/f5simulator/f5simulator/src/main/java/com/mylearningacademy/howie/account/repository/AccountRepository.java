package com.mylearningacademy.howie.account.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mylearningacademy.howie.account.entity.Customer;
import com.mylearningacademy.howie.account.entity.Request;


public interface AccountRepository extends JpaRepository<Customer, Integer> {

	//SELECT cust.user_id, cust.full_name FROM table_name WHERE cust_id = 2
	@Query("SELECT account FROM Customer account")
	List<Customer> findAllUsers();
	
	@Query("SELECT cust FROM Customer cust WHERE cust.user_id = :userId")
	Optional<Customer> findCustomerById(Integer userId);
	
	@Query("SELECT cust FROM Customer cust WHERE cust.username = :username")
	Optional<Customer> findCustomerByUsername(String username);
}
