package com.mylearningacademy.howie.account.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DirectorateDto {
	int directorateID;
	String directorateName;
	
	public String getDirectorateName() {
		return directorateName;
	}
	public void setDirectorateName(String directorateName) {
		this.directorateName = directorateName;
	}
	public int getDirectorateID() {
		return directorateID;
	}
	public void setDirectorateID(int directorateID) {
		this.directorateID = directorateID;
	}
	

}
