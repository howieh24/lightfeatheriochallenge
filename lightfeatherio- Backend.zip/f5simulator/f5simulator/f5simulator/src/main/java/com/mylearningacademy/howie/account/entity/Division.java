package com.mylearningacademy.howie.account.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "division")
public class Division {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="user_id_generator")
	@SequenceGenerator(name = "user_id_generator", sequenceName="req_id_seq", initialValue=1, allocationSize=1)

	int divisionId;
	String division;
	
	public int getDivisionId() {
		return divisionId;
	}
	public void setDivisionId(int divisionId) {
		this.divisionId = divisionId;
	}
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	
}
