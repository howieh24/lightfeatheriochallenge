package com.mylearningacademy.howie.service;


import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

@Service
public class FileUploadServiceImpl implements FileUploadService {
	
	@Value("${file.storage.path:/Users/hxiaopen/storage/}")
	private Path targetLocation;

	@Override
	public HttpStatus upload(MultipartFile file) {
		
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		if (fileName.contains("..")) {
			return HttpStatus.BAD_REQUEST;
		}
		
		try {
			Path newFile = this.targetLocation.resolve(fileName);
			Files.copy(file.getInputStream(), newFile, StandardCopyOption.REPLACE_EXISTING);
		} catch (Exception ioe) {
			System.err.println("upload exception: " + ioe.getMessage());
			return HttpStatus.BAD_REQUEST;
		}
		
		return HttpStatus.OK;
	}

	
}
