package com.mylearningacademy.howie.service;

import org.springframework.http.HttpStatus;

import com.mylearningacademy.howie.account.dto.ProgramDto;

public interface ProgramService {
	HttpStatus registerProg(ProgramDto progDto);

}
