package com.mylearningacademy.howie.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.mylearningacademy.howie.account.dto.RequestDto;
import com.mylearningacademy.howie.account.entity.Request;
import com.mylearningacademy.howie.account.repository.RequestRepository;

@Service
public class RequestServiceImpl implements RequestService{
	@Autowired
	RequestRepository repRepo;
	
	@Override
	public HttpStatus request(RequestDto reqDto) {
		Request req = new Request();
		
		req.setDirectorate(reqDto.getDirectorate());
		req.setDivision(reqDto.getDivision());
		req.setEnddate(reqDto.getEnddate());
		req.setFundingmanager(reqDto.getFundingmanager());
		req.setFundingsource(reqDto.getFundingsource());
		req.setJustification(reqDto.getJustification());
		req.setNasaprogram(reqDto.getNasaprogram());
		req.setSponsoringorg(reqDto.getSponsoringorg());
		req.setCreatedby(new Date());
		
		this.repRepo.save(req);
		
		return HttpStatus.OK;
	}

}
