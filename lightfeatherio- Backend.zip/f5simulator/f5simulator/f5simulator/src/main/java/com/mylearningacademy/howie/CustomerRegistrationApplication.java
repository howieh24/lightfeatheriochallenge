package com.mylearningacademy.howie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.mylearningacademy.howie.config.F5ConfigProperties;

//@SpringBootApplication(exclude = { SecurityAutoConfiguration.class }) // to prevent the default login
@SpringBootApplication
@EnableConfigurationProperties(F5ConfigProperties.class)
public class CustomerRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerRegistrationApplication.class, args);
	}
	
	/*
	 * @Override protected void configure(HttpSecurity http) throws Exception {
	 * http.authorizeRequests().anyRequest().authenticated() .and() .x509()
	 * .subjectPrincipalRegex("CN=(.*?)(?:,|$)")
	 * .userDetailsService(userDetailsService()); }
	 * 
	 * @Bean public UserDetailsService userDetailsService() { return new
	 * UserDetailsService() {
	 * 
	 * @Override public UserDetails loadUserByUsername(String username) throws
	 * UsernameNotFoundException { if (username.equals("Bob")) { return new
	 * User(username, "",
	 * AuthorityUtils.commaSeparatedStringToAuthorityList("ROLE_USER")); } throw new
	 * UsernameNotFoundException("User not found!"); } }; }
	 */

}
