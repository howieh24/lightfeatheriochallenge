package com.mylearningacademy.howie.service;

import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartFile;

public interface FileUploadService {
	public HttpStatus upload(MultipartFile file);
}
