package com.mylearningacademy.howie.account.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProgramDto {
	int ProgramId;
	String ProjectName;
	
	public int getProgramId() {
		return ProgramId;
	}
	public void setProgramId(int programId) {
		ProgramId = programId;
	}
	public String getProjectName() {
		return ProjectName;
	}
	public void setProjectName(String projectName) {
		ProjectName = projectName;
	}
	
	

}
