package com.mylearningacademy.howie.account.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "directorate")
public class Directorate {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="user_id_generator")
	@SequenceGenerator(name = "user_id_generator", sequenceName="req_id_seq", initialValue=1, allocationSize=1)
	int directorateID;
	String directorate;
	
	public int getDirectorateID() {
		return directorateID;
	}
	public void setDirectorateID(int directorateID) {
		this.directorateID = directorateID;
	}
	public String getDirectorate() {
		return directorate;
	}
	public void setDirectorate(String directorate) {
		this.directorate = directorate;
	}

}
