package com.mylearningacademy.howie.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mylearningacademy.howie.account.dto.ProgramDto;
import com.mylearningacademy.howie.account.dto.RequestDto;
import com.mylearningacademy.howie.account.repository.ProgramRepository;
import com.mylearningacademy.howie.account.repository.RequestRepository;
import com.mylearningacademy.howie.service.ProgramService;
import com.mylearningacademy.howie.service.RequestService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/Account")
public class ProgramController {
	HttpHeaders respHeaders = new HttpHeaders();
	
	@Autowired
	ProgramRepository progRepo;
	
	@Autowired
	ProgramService prog;
	
	@PostMapping(value="/registerProg")
	public ResponseEntity<String> registerProgr(@RequestBody ProgramDto programDto) throws Exception {
		
		String retStatus = "Success";

		HttpStatus hStatus = HttpStatus.OK;
		
		prog.registerProg(programDto);
		
		if (!retStatus.equals("Success")) {
			hStatus = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		
		return new ResponseEntity<>(retStatus, null, hStatus);}

}
