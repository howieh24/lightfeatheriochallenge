package com.mylearningacademy.howie.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.mylearningacademy.howie.account.dto.CustomerDto;
import com.mylearningacademy.howie.account.entity.Customer;
import com.mylearningacademy.howie.account.repository.AccountRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	AccountRepository acctRepo;
	
	@Override
	public HttpStatus register(CustomerDto custDto) {
		Customer cust = new Customer();
		cust.setFull_name(custDto.getFull_name());
		cust.setEmail(custDto.getEmail());
		cust.setUsername(custDto.getUsername());
		cust.setOrg(custDto.getOrg());
		cust.setPhone(custDto.getPhone());
		cust.setSalutation(custDto.getSalutation());
		cust.setSponsor(custDto.getSponsor());
		cust.setPasswd(custDto.getPasswd());
		
		this.acctRepo.save(cust);
		
		return HttpStatus.OK;
	}

	@Override
	public String update(CustomerDto custDto) {
		Optional<Customer> cust = acctRepo.findById(custDto.getUser_id());
		String status = "Success";
		if (!cust.isPresent()) {
			return "Customer cannot be found by the ID.";
		}
		try {
			cust.get().setEmail(custDto.getEmail());
			cust.get().setUsername(custDto.getUsername());
			cust.get().setOrg(custDto.getOrg());
			cust.get().setPhone(custDto.getPhone());
			cust.get().setSalutation(custDto.getSalutation());
			cust.get().setSponsor(custDto.getSponsor());
		
			this.acctRepo.save(cust.get());
			
		}catch (Exception e) {
			status = "Error " + e.getMessage();
		}
		
		return status;
	}

	@Override
	public String changePassword(CustomerDto custDto) {
		Optional<Customer> cust = acctRepo.findById(custDto.getUser_id());
		String status = "Success";
		
		if (!cust.isPresent()) {
			return "Customer cannot be found by the ID.";
		}
		try {
			cust.get().setPasswd(custDto.getPasswd());
		
			this.acctRepo.save(cust.get());
			
		}catch (Exception e) {
			status = "Error " + e.getMessage();
		}
		
		
		return status;
	}

	@Override
	public List<Customer> findAllUsers() {
		List<Customer> cust = acctRepo.findAllUsers();
		
		return cust;
	}
	
	@Override
	public Optional<Customer> findCustomerById(Integer userId){
		Optional<Customer> cust = acctRepo.findCustomerById(userId);
		
		return cust;
	}


}
