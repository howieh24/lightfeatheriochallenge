package com.mylearningacademy.howie.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.mylearningacademy.howie.account.dto.CustomerDto;
import com.mylearningacademy.howie.account.entity.Customer;
import com.mylearningacademy.howie.account.repository.AccountRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	AccountRepository acctRepo;
	
	@Override
	public HttpStatus register(CustomerDto custDto) {
		Customer cust = new Customer();
		cust.setFirstName(custDto.getFirstName());
		cust.setEmail(custDto.getEmail());
		cust.setLastName(custDto.getLastName());
		cust.setPhone(custDto.getPhone());
		cust.setJurisdiction(custDto.getJurisdiction());
		
		this.acctRepo.save(cust);
		
		return HttpStatus.OK;
	}

	@Override
	public List<Customer> findAllUsers() {
		List<Customer> cust = acctRepo.findAllUsers();
		
		return cust;
	}
	
	@Override
	public Optional<Customer> findCustomerById(Integer userId){
		Optional<Customer> cust = acctRepo.findCustomerById(userId);
		
		return cust;
	}

}
