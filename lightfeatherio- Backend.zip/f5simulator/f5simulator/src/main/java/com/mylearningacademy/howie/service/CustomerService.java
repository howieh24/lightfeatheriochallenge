package com.mylearningacademy.howie.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;

import com.mylearningacademy.howie.account.dto.CustomerDto;
import com.mylearningacademy.howie.account.entity.Customer;

public interface CustomerService {
	HttpStatus register(CustomerDto custDto);
	List<Customer> findAllUsers();
	Optional<Customer> findCustomerById(Integer userId);
}
