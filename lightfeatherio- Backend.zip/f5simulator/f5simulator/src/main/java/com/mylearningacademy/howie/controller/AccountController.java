package com.mylearningacademy.howie.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mylearningacademy.howie.service.CustomerService;
import com.mylearningacademy.howie.service.FileUploadService;
import com.mylearningacademy.howie.account.dto.CustomerDto;
import com.mylearningacademy.howie.account.entity.Customer;
import com.mylearningacademy.howie.account.repository.AccountRepository;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/account")
public class AccountController {

	HttpHeaders respHeaders = new HttpHeaders();
	
	@Autowired
	AccountRepository acctRepo;
	
	@Autowired
	FileUploadService fileService;
	
	@Autowired
	CustomerService customer;
	
	public AccountController() {
		respHeaders.setContentType(MediaType.APPLICATION_JSON);
	}
	
	@PostMapping(value="/submit")
	public ResponseEntity<String> register(@RequestBody CustomerDto custDto) {
		String retStatus = "Success";
		
		customer.register(custDto);
		
		return new ResponseEntity<>(retStatus, null, HttpStatus.OK);
	}
	
	@PostMapping("/upload/file")
	public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file, HttpServletRequest request) {
		
		HttpStatus status = this.fileService.upload(file);
		String message = "success";
		if (status != HttpStatus.OK) {
			message = "failure";
		}
		
		HttpHeaders headers = new HttpHeaders();
	    headers.add("content-type", "text/plain");
		
		return new ResponseEntity<>(message, headers, status);
	}
	
	@GetMapping("/test")
	public ResponseEntity<String> test(HttpServletRequest request) {
		
		String message = "success";
		HttpHeaders headers = new HttpHeaders();
	    headers.add("content-type", "text/plain");
		
		return new ResponseEntity<>(message, headers, HttpStatus.OK);
	}
	
	@GetMapping("/viewAllUsers")
	public ResponseEntity<List<Customer>> findAllUsers(){
		List<Customer> allUsers = this.customer.findAllUsers();
		HttpStatus status = HttpStatus.OK;
		HttpHeaders headers = new HttpHeaders();
	    headers.add("content-type", "application/json"); 
		
		if(allUsers.isEmpty()) {
			status = HttpStatus.BAD_REQUEST;
		}
		
		return new ResponseEntity<>(allUsers,headers,status);
		
	}
	
	@GetMapping("/adminUpdate/{userId}")
	public ResponseEntity<Customer> getCustomerByID(@PathVariable Integer userId){
		Optional<Customer> cust = this.customer.findCustomerById(userId);
		HttpStatus status = HttpStatus.OK;

	    this.respHeaders.add("content-type", "application/json"); 
		if(!cust.isPresent()) {
			status = HttpStatus.BAD_REQUEST;
		}
		
		return new ResponseEntity<>(cust.get(), this.respHeaders,status);
		
	}
	
}
