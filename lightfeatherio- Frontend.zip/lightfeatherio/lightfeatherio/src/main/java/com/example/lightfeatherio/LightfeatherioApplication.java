package com.example.lightfeatherio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LightfeatherioApplication {

	public static void main(String[] args) {
		SpringApplication.run(LightfeatherioApplication.class, args);
	}

}
