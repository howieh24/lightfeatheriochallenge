package com.lightfeather.codechallenge.serviceimpl;

import java.util.List;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.lang.Comparable;

import org.apache.logging.log4j.util.PropertySource.Comparator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.lightfeather.codechallenge.dto.ManagerDto;
import com.lightfeather.codechallenge.dto.UserInfoDto;
import com.lightfeather.codechallenge.service.ManagerServiceInterface;

import io.micrometer.common.util.StringUtils;

import com.lightfeather.codechallenge.entity.Manager;

@Service
public class ManagerServiceImpl implements ManagerServiceInterface {
	List<ManagerDto> managers = new ArrayList<>();
	
	@Autowired
	RestTemplate restTemplate;

	@Override
	public List<ManagerDto> getManagerList() {
		managers = getManagerData();
		
		return managers;
	}
	
	
	
	private List<ManagerDto> getManagerData() {
		
	     HttpHeaders headers = new HttpHeaders();
	     headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	     HttpEntity <String> entity = new HttpEntity<String>(headers);
	      
	     //String managerData = restTemplate.getForEntity("https://o3m5qixdng.execute-api.us-east-1.amazonaws.com/api/managers", HttpMethod.GET, entity, List<Manager>().class).getBody();
	     
	     ResponseEntity<List<Manager>> responseEntity = 
				  restTemplate.exchange(
						  "https://o3m5qixdng.execute-api.us-east-1.amazonaws.com/api/managers",
						  HttpMethod.GET,
						  null,
						  new ParameterizedTypeReference<List<Manager>>() {}
				  );
		
	     List<Manager> users = responseEntity.getBody();
				
	     List<ManagerDto> mgrDtoList = listMapper(users);
	     
			/*
			 * mgrDtoList .stream() .sorted((object1, object2) ->
			 * object1.getJurisdiction().compareTo(object2.getJurisdiction())) ;
			 */				
	     return mgrDtoList;
	 }
	
	
	private static List<ManagerDto> listMapper(List<Manager> managers) {
		Object aManager;
		List<ManagerDto> mgrDtoList = new ArrayList<>();
		
		for (int i = 0; i< managers.size(); i++) {
			aManager = managers.get(i);
			ManagerDto mgrDto = (ManagerDto) objectMapper(aManager);
			try {
		        Integer jura = Integer.parseInt(mgrDto.getJurisdiction());
		    } catch (NumberFormatException nfe) {
		    	mgrDtoList.add(mgrDto);
		    }
			
		}
		
		return mgrDtoList;
	}
	
	private static Object objectMapper(Object manager){
    	ObjectMapper mapper = new ObjectMapper();
    	mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    	ManagerDto mgrDto = mapper.convertValue(manager, ManagerDto.class);
        return mgrDto;
    }



	@Override
	public String submitNotif(UserInfoDto userInfo) {
		
		if(StringUtils.isEmpty(userInfo.getFirstName())){
			return "ERROR: Missing First Name";
		}else if(StringUtils.isEmpty(userInfo.getLastName())) {
			return "ERROR: Missing Last Name";
		}else if (StringUtils.isEmpty(userInfo.getSupervisor())) {
			return "ERROR: Missing Supervisor";
		}else {
			System.out.println("First name: " + userInfo.getFirstName());
			System.out.println("Last name: " + userInfo.getLastName());
			System.out.println("Email: " + userInfo.getEmail());
			System.out.println("Phone Number: " + userInfo.getPhone());
			System.out.println("Supervisor: " + userInfo.getSupervisor());
			return "Success!";
		}
	}
	
	
	
	/*
	 * @Override public String[] getManagerList(){
	 * 
	 * managers[0] = "c - hu, Haoyi"; managers[1] = "c - li, kool";
	 * 
	 * Arrays.sort(managers);
	 * 
	 * return managers; }
	 */
	
	
}
