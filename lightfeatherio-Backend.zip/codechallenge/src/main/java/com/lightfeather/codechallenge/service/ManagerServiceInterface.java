package com.lightfeather.codechallenge.service;

import java.util.List;

import com.lightfeather.codechallenge.dto.ManagerDto;
import com.lightfeather.codechallenge.dto.UserInfoDto;

public interface ManagerServiceInterface {
	
	//public String[] getManagerList();
	public List<ManagerDto> getManagerList();
	public String submitNotif(UserInfoDto userInfo);
}
