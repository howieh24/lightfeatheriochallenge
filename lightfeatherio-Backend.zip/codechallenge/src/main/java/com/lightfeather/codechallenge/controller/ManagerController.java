package com.lightfeather.codechallenge.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lightfeather.codechallenge.dto.*;
import com.lightfeather.codechallenge.service.ManagerServiceInterface;


@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api")
public class ManagerController {
	
	HttpHeaders respHeaders = new HttpHeaders();
	
	@Autowired
	ManagerServiceInterface manager;
	
	public ManagerController() {
		respHeaders.setContentType(MediaType.APPLICATION_JSON);
	}
	
	@GetMapping("/supervisors")
	public ResponseEntity<List<ManagerDto>> getManagers(){
		List<ManagerDto> allManagers = this.manager.getManagerList();
		HttpStatus status = HttpStatus.OK;
		HttpHeaders headers = new HttpHeaders();
	    headers.add("content-type", "application/JSON"); 
		
		//if(allUsers.isEmpty()) {
			//status = HttpStatus.BAD_REQUEST;
		//}
		
		return new ResponseEntity<>(allManagers,headers,status);
		
	}
	
	@PostMapping("/submit")
	public ResponseEntity<String> submitReq(@RequestBody UserInfoDto userDto){
		String retStatus =  manager.submitNotif(userDto);
		
		return new ResponseEntity<>(retStatus, null, HttpStatus.OK);
	}
	
	/*
	 * @GetMapping("/managers") public String getManagerList() { HttpHeaders headers
	 * = new HttpHeaders();
	 * headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON)); HttpEntity
	 * <String> entity = new HttpEntity<String>(headers);
	 * 
	 * return restTemplate.exchange(
	 * "https://o3m5qixdng.execute-api.us-east-1.amazonaws.com/api/managers",
	 * HttpMethod.GET, entity, String.class).getBody(); }
	 */
	
}
