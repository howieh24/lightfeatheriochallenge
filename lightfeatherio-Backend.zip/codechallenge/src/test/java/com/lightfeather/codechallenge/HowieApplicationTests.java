package com.lightfeather.codechallenge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HowieApplicationTests {

	@Test
	void contextLoads() {
	}

}
